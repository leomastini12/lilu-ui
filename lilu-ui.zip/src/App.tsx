
import React, { useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import {
  Activity,
  BarChart4,
  Bell,
  Calendar as CalendarIcon,
  CheckCircle2,
  ChevronRight,
  ClipboardList,
  FileText,
  HeartPulse,
  Home,
  LayoutGrid,
  LineChart,
  LogOut,
  Mail,
  MessageSquare,
  Phone,
  Plus,
  Search,
  Settings,
  ShieldCheck,
  Stethoscope,
  Users,
  Video,
} from "lucide-react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart as RLineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  BarChart,
  Bar,
} from "recharts";

const brand = {
  gradient: "bg-gradient-to-r from-fuchsia-600 via-purple-600 to-indigo-600",
  textGradient: "bg-gradient-to-r from-fuchsia-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent",
};

const navItems = [
  { key: "dashboard", label: "Dashboard", icon: Home },
  { key: "members", label: "Membros", icon: Users },
  { key: "profile", label: "Perfil", icon: HeartPulse },
  { key: "careplans", label: "Planos de Cuidado", icon: ClipboardList },
  { key: "tele", label: "Teleconsulta", icon: Video },
  { key: "appointments", label: "Agenda", icon: CalendarIcon },
  { key: "messages", label: "Mensagens", icon: MessageSquare },
  { key: "analytics", label: "Analytics", icon: BarChart4 },
  { key: "admin", label: "Admin", icon: ShieldCheck },
  { key: "settings", label: "Configurações", icon: Settings },
];

const kpis = [
  { label: "Membros Ativos", value: "12.480", delta: "+3.1%" },
  { label: "Risco Alto", value: "1.146", delta: "-0.6%" },
  { label: "Teleconsultas (30d)", value: "2.341", delta: "+12%" },
  { label: "NPS", value: "74", delta: "+4" },
];

const trendData = Array.from({ length: 12 }).map((_, i) => ({
  month: new Date(2024, i).toLocaleString("pt-BR", { month: "short" }),
  consultas: Math.round(1200 + Math.random() * 900 + i * 80),
  engajamento: Math.round(45 + Math.random() * 15 + i * 1.5),
}));

const membersSeed = [
  { id: "84721", nome: "Ana Paula", cpf: "***.***.***-12", idade: 52, risco: "alto", programa: "Hipertensão", ultimaAcao: "Hoje" },
  { id: "84722", nome: "Carlos Silva", cpf: "***.***.***-45", idade: 61, risco: "médio", programa: "Diabetes", ultimaAcao: "Ontem" },
  { id: "84723", nome: "Mariana Souza", cpf: "***.***.***-88", idade: 36, risco: "baixo", programa: "Saúde Mental", ultimaAcao: "2 dias" },
  { id: "84724", nome: "Rafael Lima", cpf: "***.***.***-03", idade: 43, risco: "médio", programa: "Obesidade", ultimaAcao: "3 dias" },
  { id: "84725", nome: "João Pedro", cpf: "***.***.***-19", idade: 58, risco: "alto", programa: "Cardio", ultimaAcao: "Hoje" },
];

function RiskBadge({ level }: { level: "alto" | "médio" | "baixo" }) {
  const map: Record<string, string> = {
    alto: "bg-rose-100 text-rose-700",
    médio: "bg-amber-100 text-amber-700",
    baixo: "bg-emerald-100 text-emerald-700",
  };
  return <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${map[level]}`}>{level}</span>;
}

function Topbar({ onLogout }: { onLogout?: () => void }) {
  return (
    <div className={`h-16 flex items-center justify-between px-4 border-b bg-white/70 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-30`}>
      <div className="flex items-center gap-3">
        <div className={`w-9 h-9 rounded-2xl ${brand.gradient} shadow-md`} />
        <div className={`text-xl font-semibold ${brand.textGradient}`}>Lilu</div>
        <Badge className="ml-2 rounded-xl" variant="secondary">beta</Badge>
      </div>
      <div className="hidden md:flex items-center gap-2 min-w-[360px]">
        <div className="relative flex-1">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Buscar membros, exames, protocolos…" className="pl-8" />
        </div>
        <Button variant="secondary" size="icon"><Bell className="h-4 w-4" /></Button>
        <Avatar className="h-9 w-9">
          <AvatarFallback>LM</AvatarFallback>
        </Avatar>
      </div>
      <div className="md:hidden">
        <Button variant="secondary" size="icon"><LayoutGrid className="h-4 w-4"/></Button>
      </div>
    </div>
  );
}

function Sidebar({ current, setCurrent }: { current: string; setCurrent: (k: string) => void }) {
  return (
    <aside className="w-[250px] hidden md:flex flex-col gap-1 p-3 border-r bg-white min-h-[calc(100vh-4rem)] sticky top-16">
      {navItems.map(({ key, label, icon: Icon }) => (
        <button
          key={key}
          onClick={() => setCurrent(key)}
          className={`flex items-center gap-3 px-3 py-2 rounded-xl text-sm transition group text-left ${
            current === key ? `bg-gradient-to-r from-fuchsia-50 to-purple-50 text-purple-700 border border-purple-100` : `hover:bg-muted`
          }`}
        >
          <Icon className={`h-4 w-4 ${current === key ? "text-purple-600" : "text-muted-foreground group-hover:text-foreground"}`} />
          <span className="flex-1">{label}</span>
          <ChevronRight className="h-4 w-4 opacity-50" />
        </button>
      ))}
      <div className="mt-auto pt-2 border-t">
        <Button variant="ghost" className="w-full justify-start"><LogOut className="h-4 w-4 mr-2"/>Sair</Button>
      </div>
    </aside>
  );
}

function KpiCard({ label, value, delta }: { label: string; value: string; delta: string }) {
  return (
    <Card className="rounded-2xl">
      <CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground font-medium">{label}</CardTitle></CardHeader>
      <CardContent className="pt-0">
        <div className="text-2xl font-semibold tracking-tight">{value}</div>
        <div className="text-xs text-emerald-600 mt-1">{delta}</div>
      </CardContent>
    </Card>
  );
}

function Dashboard() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {kpis.map((k) => <KpiCard key={k.label} {...k} />)}
      </div>
      <Card className="rounded-2xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><LineChart className="h-5 w-5"/>Tendência de consultas e engajamento</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData} margin={{ left: 0, right: 0 }}>
                <defs>
                  <linearGradient id="grad1" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#a21caf" stopOpacity={0.6}/>
                    <stop offset="95%" stopColor="#a21caf" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                <XAxis dataKey="month"/>
                <YAxis />
                <Tooltip />
                <Legend />
                <Area type="monotone" dataKey="consultas" stroke="#a21caf" fill="url(#grad1)" name="Consultas" />
                <Line type="monotone" dataKey="engajamento" stroke="#7c3aed" name="Engajamento (%)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="rounded-2xl lg:col-span-2">
          <CardHeader><CardTitle>Ações recentes</CardTitle></CardHeader>
          <CardContent>
            <ul className="space-y-3">
              {[1,2,3,4,5].map((i) => (
                <li key={i} className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-emerald-600 mt-0.5"/>
                  <div className="text-sm">
                    <div className="font-medium">Contato ativo com membro de risco alto</div>
                    <div className="text-muted-foreground">Enfermeira Becca concluiu acompanhamento por WhatsApp</div>
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
        <Card className="rounded-2xl">
          <CardHeader><CardTitle>Próximas teleconsultas</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {["Ana Paula","Carlos Silva","João Pedro"].map((n, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-xl border">
                <div>
                  <div className="text-sm font-medium">{n}</div>
                  <div className="text-xs text-muted-foreground">Hoje • {9+i}:30</div>
                </div>
                <Button size="sm" variant="secondary"><Video className="h-4 w-4 mr-2"/>Entrar</Button>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Members({ onOpenProfile }: { onOpenProfile: (id: string) => void }) {
  const [query, setQuery] = useState("");
  const [risk, setRisk] = useState<string>("todos");

  const data = useMemo(() => {
    return membersSeed.filter(m =>
      (risk === "todos" || m.risco === risk) &&
      (m.nome.toLowerCase().includes(query.toLowerCase()) || m.cpf.includes(query))
    );
  }, [query, risk]);

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-end">
        <div className="flex-1">
          <Label>Busca</Label>
          <div className="relative">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground"/>
            <Input placeholder="Nome ou CPF" className="pl-8" value={query} onChange={e=>setQuery(e.target.value)} />
          </div>
        </div>
        <div className="w-full sm:w-[220px]">
          <Label>Risco</Label>
          <Select defaultValue="todos" onValueChange={(v:any)=>setRisk(v)}>
            <SelectTrigger><SelectValue placeholder="Filtrar por risco"/></SelectTrigger>
            <SelectContent>
              <SelectItem value="todos" onSelect={setRisk}>Todos</SelectItem>
              <SelectItem value="alto" onSelect={setRisk}>Alto</SelectItem>
              <SelectItem value="médio" onSelect={setRisk}>Médio</SelectItem>
              <SelectItem value="baixo" onSelect={setRisk}>Baixo</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button className="sm:ml-auto"><Plus className="h-4 w-4 mr-2"/>Novo membro</Button>
      </div>

      <Card className="rounded-2xl">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50">
                <tr>
                  <th className="text-left p-3 font-medium">Nome</th>
                  <th className="text-left p-3 font-medium">CPF</th>
                  <th className="text-left p-3 font-medium">Idade</th>
                  <th className="text-left p-3 font-medium">Programa</th>
                  <th className="text-left p-3 font-medium">Risco</th>
                  <th className="text-right p-3 font-medium">Ação</th>
                </tr>
              </thead>
              <tbody>
                {data.map((m) => (
                  <tr key={m.id} className="border-b hover:bg-muted/40">
                    <td className="p-3">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-8 w-8"><AvatarFallback>{m.nome.split(" ").map(s=>s[0]).slice(0,2).join("")}</AvatarFallback></Avatar>
                        <div>
                          <div className="font-medium">{m.nome}</div>
                          <div className="text-xs text-muted-foreground">Última ação: {m.ultimaAcao}</div>
                        </div>
                      </div>
                    </td>
                    <td className="p-3">{m.cpf}</td>
                    <td className="p-3">{m.idade}</td>
                    <td className="p-3">{m.programa}</td>
                    <td className="p-3"><RiskBadge level={m.risco as any}/></td>
                    <td className="p-3 text-right">
                      <Button size="sm" variant="secondary" onClick={()=>onOpenProfile(m.id)}>Abrir</Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function MemberProfile({ id }: { id: string }) {
  const member = membersSeed.find(m => m.id === id) ?? membersSeed[0];
  return (
    <div className="space-y-4">
      <div className="flex flex-col lg:flex-row lg:items-center gap-4">
        <div className="flex items-center gap-3">
          <Avatar className="h-12 w-12"><AvatarFallback>{member.nome.split(" ").map(s=>s[0]).slice(0,2).join("")}</AvatarFallback></Avatar>
          <div>
            <div className="text-xl font-semibold">{member.nome}</div>
            <div className="text-sm text-muted-foreground">{member.cpf} • {member.idade} anos</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <RiskBadge level={member.risco as any} />
          <Badge variant="secondary">{member.programa}</Badge>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <Button variant="secondary" size="sm"><Phone className="h-4 w-4 mr-2"/>Ligar</Button>
          <Button size="sm"><MessageSquare className="h-4 w-4 mr-2"/>Mensagem</Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="mb-3">
          <TabsTrigger value="overview">Visão geral</TabsTrigger>
          <TabsTrigger value="timeline">Timeline</TabsTrigger>
          <TabsTrigger value="labs">Exames</TabsTrigger>
          <TabsTrigger value="meds">Medicações</TabsTrigger>
          <TabsTrigger value="notes">Notas</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
            <Card className="rounded-2xl"><CardHeader className="pb-2"><CardTitle className="text-sm">PA média (30d)</CardTitle></CardHeader><CardContent className="text-2xl font-semibold">131/86</CardContent></Card>
            <Card className="rounded-2xl"><CardHeader className="pb-2"><CardTitle className="text-sm">Glicemia média</CardTitle></CardHeader><CardContent className="text-2xl font-semibold">112 mg/dL</CardContent></Card>
            <Card className="rounded-2xl"><CardHeader className="pb-2"><CardTitle className="text-sm">Passos/dia</CardTitle></CardHeader><CardContent className="text-2xl font-semibold">6.214</CardContent></Card>
            <Card className="rounded-2xl"><CardHeader className="pb-2"><CardTitle className="text-sm">Última consulta</CardTitle></CardHeader><CardContent className="text-2xl font-semibold">Há 9 dias</CardContent></Card>
          </div>
          <Card className="rounded-2xl">
            <CardHeader><CardTitle>Aderência ao plano</CardTitle></CardHeader>
            <CardContent>
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={[{name:"Semana 1", value:68},{name:"Semana 2", value:74},{name:"Semana 3", value:81},{name:"Semana 4", value:77}]}> 
                    <CartesianGrid strokeDasharray="3 3" opacity={0.3}/>
                    <XAxis dataKey="name"/>
                    <YAxis/>
                    <Tooltip/>
                    <Bar dataKey="value" name="% Tarefas" fill="#a21caf"/>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="timeline">
          <ul className="space-y-3">
            {[1,2,3,4].map((i)=> (
              <li key={i} className="flex items-start gap-3">
                <Activity className="h-5 w-5 text-purple-600 mt-0.5"/>
                <div className="text-sm">
                  <div className="font-medium">Mensagem de acompanhamento</div>
                  <div className="text-muted-foreground">Enfermeira enviou orientações de atividade física</div>
                </div>
              </li>
            ))}
          </ul>
        </TabsContent>
        <TabsContent value="labs">
          <Card className="rounded-2xl">
            <CardHeader><CardTitle>Exames laboratoriais</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {["Hemograma", "Glicemia", "Colesterol total"].map((n, i) => (
                <div key={i} className="flex items-center justify-between p-3 border rounded-xl">
                  <div>
                    <div className="text-sm font-medium">{n}</div>
                    <div className="text-xs text-muted-foreground">Coletado em 12/06/2025</div>
                  </div>
                  <Button variant="secondary" size="sm"><FileText className="h-4 w-4 mr-2"/>PDF</Button>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="meds">
          <Card className="rounded-2xl">
            <CardHeader><CardTitle>Medicações</CardTitle></CardHeader>
            <CardContent className="grid gap-3">
              <div className="flex items-center justify-between p-3 border rounded-xl">
                <div>
                  <div className="text-sm font-medium">Losartana 50mg</div>
                  <div className="text-xs text-muted-foreground">1x ao dia • manhã</div>
                </div>
                <Switch defaultChecked/>
              </div>
              <div className="flex items-center justify-between p-3 border rounded-xl">
                <div>
                  <div className="text-sm font-medium">Metformina 850mg</div>
                  <div className="text-xs text-muted-foreground">2x ao dia</div>
                </div>
                <Switch />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="notes">
          <Card className="rounded-2xl">
            <CardHeader><CardTitle>Notas clínicas</CardHeader></CardTitle>
            <CardContent className="space-y-3">
              <Textarea placeholder="Registre um novo atendimento, evolução ou orientação…" />
              <div className="text-right"><Button>Salvar nota</Button></div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function CarePlans() {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Button><Plus className="h-4 w-4 mr-2"/>Novo plano</Button>
        <Button variant="secondary">Importar protocolo</Button>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {["Hipertensão", "Diabetes", "Saúde Mental"].map((n,i)=>(
          <Card key={i} className="rounded-2xl">
            <CardHeader><CardTitle>{n}</CardTitle></CardHeader>
            <CardContent className="text-sm text-muted-foreground">Conjunto de tarefas, metas e lembretes para acompanhamento semanal.</CardContent>
            <CardFooter className="justify-end"><Button variant="secondary" size="sm">Abrir</Button></CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}

function Tele() {
  return (
    <div className="space-y-4">
      <Card className="rounded-2xl">
        <CardHeader><CardTitle className="flex items-center gap-2"><Video className="h-5 w-5"/>Sala de teleconsulta</CardTitle></CardHeader>
        <CardContent>
          <div className={`aspect-video w-full rounded-2xl border ${brand.gradient} grid place-items-center text-white text-sm`}>Vídeo aqui</div>
          <div className="mt-3 flex items-center gap-2">
            <Button variant="secondary"><MicIcon/>Microfone</Button>
            <Button variant="secondary"><Video/>Câmera</Button>
            <Button className="bg-rose-600 hover:bg-rose-700">Encerrar</Button>
          </div>
        </CardContent>
      </Card>
      <Card className="rounded-2xl">
        <CardHeader><CardTitle>Próximas consultas</CardTitle></CardHeader>
        <CardContent className="grid gap-3">
          {[1,2,3].map(i=> (
            <div key={i} className="flex items-center justify-between p-3 border rounded-xl">
              <div>
                <div className="text-sm font-medium">Ana Paula</div>
                <div className="text-xs text-muted-foreground">Amanhã • 09:30 • Cardiologia</div>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="secondary" size="sm"><Phone className="h-4 w-4 mr-2"/>Ligar</Button>
                <Button size="sm"><Video className="h-4 w-4 mr-2"/>Entrar</Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}

function Appointments() {
  return (
    <div className="space-y-4">
      <Card className="rounded-2xl">
        <CardHeader><CardTitle>Agendar</CardTitle></CardHeader>
        <CardContent className="grid md:grid-cols-3 gap-3">
          <div>
            <Label>Membro</Label>
            <Input placeholder="Nome ou CPF"/>
          </div>
          <div>
            <Label>Especialidade</Label>
            <Select defaultValue="cardio">
              <SelectTrigger><SelectValue placeholder="Cardiologia"/></SelectTrigger>
              <SelectContent>
                <SelectItem value="cardio">Cardiologia</SelectItem>
                <SelectItem value="endo">Endocrinologia</SelectItem>
                <SelectItem value="psico">Psicologia</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Data & hora</Label>
            <Input type="datetime-local"/>
          </div>
          <div className="md:col-span-3 text-right"><Button><CalendarIcon className="h-4 w-4 mr-2"/>Criar</Button></div>
        </CardContent>
      </Card>
      <Card className="rounded-2xl">
        <CardHeader><CardTitle>Próximos atendimentos</CardTitle></CardHeader>
        <CardContent className="grid gap-3">
          {[1,2,3,4].map(i => (
            <div key={i} className="flex items-center justify-between p-3 border rounded-xl">
              <div>
                <div className="text-sm font-medium">Maria Fernanda</div>
                <div className="text-xs text-muted-foreground">12/09 • 14:00 • Nutrição</div>
              </div>
              <Button variant="secondary" size="sm">Detalhes</Button>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}

function Messages() {
  return (
    <div className="grid grid-rows-[1fr_auto] h-full min-h-[480px]">
      <div className="p-3 space-y-3 overflow-auto">
        {[
          { who: "member", text: "Oi, tudo bem? Minha pressão subiu hoje." },
          { who: "nurse", text: "Oi! Você tomou a medicação? Me conta como foi sua manhã." },
        ].map((m, i) => (
          <div key={i} className={`max-w-[70%] p-3 rounded-2xl ${m.who === "member" ? "bg-muted self-start" : `text-white ${brand.gradient}`}`}>{m.text}</div>
        ))}
      </div>
      <div className="p-3 border-t flex items-center gap-2">
        <Input placeholder="Escreva uma mensagem…"/>
        <Button><Mail className="h-4 w-4 mr-2"/>Enviar</Button>
      </div>
    </div>
  );
}

function Analytics() {
  const dataset = trendData;
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="rounded-2xl">
          <CardHeader><CardTitle>Consultas por mês</CardTitle></CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <RLineChart data={dataset}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.3}/>
                <XAxis dataKey="month"/>
                <YAxis/>
                <Tooltip/>
                <Line type="monotone" dataKey="consultas" stroke="#7c3aed" name="Consultas" />
              </RLineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        <Card className="rounded-2xl">
          <CardHeader><CardTitle>Engajamento (%)</CardTitle></CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={dataset}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.3}/>
                <XAxis dataKey="month"/>
                <YAxis/>
                <Tooltip/>
                <Area type="monotone" dataKey="engajamento" stroke="#a21caf" fill="#f5d0fe" name="%"/>
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Admin() {
  return (
    <div className="space-y-4">
      <Card className="rounded-2xl">
        <CardHeader><CardTitle>Usuários e permissões</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto p-0">
          <table className="w-full text-sm">
            <thead className="bg-muted/50">
              <tr>
                <th className="text-left p-3">Nome</th>
                <th className="text-left p-3">Cargo</th>
                <th className="text-left p-3">Permissão</th>
                <th className="text-right p-3">Ações</th>
              </tr>
            </thead>
            <tbody>
              {[
                { nome: "Becca", cargo: "Enfermeira", perm: "Profissional de saúde" },
                { nome: "Marcia", cargo: "Comercial", perm: "Leitura" },
                { nome: "Eliana", cargo: "RH", perm: "Admin" },
              ].map((u,i)=>(
                <tr key={i} className="border-b">
                  <td className="p-3">{u.nome}</td>
                  <td className="p-3">{u.cargo}</td>
                  <td className="p-3">{u.perm}</td>
                  <td className="p-3 text-right"><Button size="sm" variant="secondary">Editar</Button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}

function Settings() {
  return (
    <div className="grid gap-4">
      <Card className="rounded-2xl">
        <CardHeader><CardTitle>Marca e aparência</CardTitle></CardHeader>
        <CardContent className="grid md:grid-cols-3 gap-3">
          <div className="md:col-span-2">
            <Label>Nome da organização</Label>
            <Input defaultValue="Lilu"/>
          </div>
          <div>
            <Label>Modo escuro</Label>
            <div className="h-10 flex items-center"><Switch defaultChecked/></div>
          </div>
          <div className="md:col-span-3">
            <Label>Assinatura de e-mail</Label>
            <Textarea defaultValue={"Lilu — Era do Cuidado"}/>
          </div>
        </CardContent>
        <CardFooter className="justify-end"><Button>Salvar</Button></CardFooter>
      </Card>
    </div>
  );
}

function MicIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" className="mr-2"><path d="M12 14a3 3 0 0 0 3-3V6a3 3 0 1 0-6 0v5a3 3 0 0 0 3 3z"></path><path d="M19 11a7 7 0 0 1-14 0" stroke="currentColor" strokeWidth="2" fill="none"/><path d="M12 19v3" stroke="currentColor" strokeWidth="2"/></svg>
  );
}

export default function App() {
  const [current, setCurrent] = useState<string>("dashboard");
  const [profileId, setProfileId] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-white to-purple-50">
      <Topbar />
      <div className="mx-auto max-w-[1400px] px-3 md:px-6 grid grid-cols-1 md:grid-cols-[250px_1fr] gap-6">
        <Sidebar current={current} setCurrent={setCurrent} />
        <main className="py-4">
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              {(() => {
                const item = navItems.find(n => n.key === current);
                const Icon = item?.icon ?? Home;
                return (
                  <>
                    <div className={`h-9 w-9 rounded-2xl grid place-items-center text-white ${brand.gradient}`}>
                      <Icon className="h-4 w-4"/>
                    </div>
                    <h1 className="text-xl font-semibold">{item?.label ?? "Dashboard"}</h1>
                  </>
                );
              })()}
            </div>
            <div className="hidden sm:flex items-center gap-2">
              <Button variant="secondary"><Stethoscope className="h-4 w-4 mr-2"/>Protocolos</Button>
              <Button onClick={()=>setCurrent('members')}><Plus className="h-4 w-4 mr-2"/>Ação rápida</Button>
            </div>
          </div>

          {current === "dashboard" && <Dashboard />}
          {current === "members" && <Members onOpenProfile={(id)=>{ setProfileId(id); setCurrent("profile"); }} />}
          {current === "profile" && <MemberProfile id={profileId ?? membersSeed[0].id} />}
          {current === "careplans" && <CarePlans />}
          {current === "tele" && <Tele />}
          {current === "appointments" && <Appointments />}
          {current === "messages" && <Messages />}
          {current === "analytics" && <Analytics />}
          {current === "admin" && <Admin />}
          {current === "settings" && <Settings />}
        </main>
      </div>
      <footer className="py-8 text-center text-xs text-muted-foreground">
        Feito com ❤ na <span className={brand.textGradient}>Era do Cuidado</span>. Lilu — interface de demonstração.
      </footer>
    </div>
  );
}
