
import React from 'react'
export function Select({defaultValue, onValueChange, children}: any){
  return <div data-default={defaultValue} data-change={onValueChange}>{children}</div>
}
export function SelectTrigger({children}: any){ return <div className='h-10 rounded-xl border px-3 flex items-center justify-between'>{children}</div> }
export function SelectValue({placeholder}: any){ return <span className='text-slate-500'>{placeholder||''}</span> }
export function SelectContent({children}: any){ return <div className='p-2 border rounded-xl mt-2 bg-white'>{children}</div> }
export function SelectItem({value, children, onSelect}: any){
  return <div className='px-3 py-2 rounded-lg hover:bg-slate-100 cursor-pointer' onClick={(e)=>{onSelect&&onSelect(value);}}>{children}</div>
}
