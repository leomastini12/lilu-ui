
import React from 'react'
import clsx from 'clsx'
export function Card({children, className}: any){ return <div className={clsx('border rounded-2xl bg-white', className)}>{children}</div> }
export function CardHeader({children, className}: any){ return <div className={clsx('p-4 border-b', className)}>{children}</div> }
export function CardTitle({children, className}: any){ return <h3 className={clsx('font-semibold', className)}>{children}</h3> }
export function CardContent({children, className}: any){ return <div className={clsx('p-4', className)}>{children}</div> }
export function CardFooter({children, className}: any){ return <div className={clsx('p-4 border-t flex', className)}>{children}</div> }
