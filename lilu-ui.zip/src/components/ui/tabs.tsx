
import React, { useState, createContext, useContext } from 'react'
const Ctx = createContext<any>(null)
export function Tabs({defaultValue, children, className}: any){
  const [value, setValue] = useState(defaultValue)
  return <Ctx.Provider value={{value,setValue}}><div className={className}>{children}</div></Ctx.Provider>
}
export function TabsList({children, className}: any){ return <div className={'flex gap-2 '+(className||'')}>{children}</div> }
export function TabsTrigger({value, children}: any){
  const ctx = useContext(Ctx)
  const active = ctx.value===value
  return <button onClick={()=>ctx.setValue(value)} className={(active?'bg-purple-600 text-white':'bg-slate-100 text-slate-900')+' px-3 h-9 rounded-xl text-sm'}>{children}</button>
}
export function TabsContent({value, children, className}: any){
  const ctx = useContext(Ctx)
  if(ctx.value!==value) return null
  return <div className={className}>{children}</div>
}
