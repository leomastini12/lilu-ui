
import React from 'react'
export function Label({children, className}: any){
  return <label className={'text-xs font-medium text-slate-600 '+(className||'')}>{children}</label>
}
