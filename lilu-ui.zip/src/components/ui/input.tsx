
import React from 'react'
export function Input(props: any){
  return <input {...props} className={'h-10 w-full rounded-xl border px-3 outline-none focus:ring-2 focus:ring-purple-300 '+(props.className||'')} />
}
