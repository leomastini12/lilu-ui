
import React from 'react'
import clsx from 'clsx'
export function Button({children, className, variant='default', size='md', ...props}: any){
  const variants:any = {
    default: 'bg-purple-600 hover:bg-purple-700 text-white',
    secondary: 'bg-slate-100 hover:bg-slate-200 text-slate-900',
    ghost: 'bg-transparent hover:bg-slate-100 text-slate-900'
  }
  const sizes:any = { sm:'h-8 px-3 text-sm', md:'h-10 px-4', lg:'h-11 px-5' }
  return <button className={clsx('inline-flex items-center justify-center rounded-xl transition', variants[variant], sizes[size], className)} {...props}>{children}</button>
}
