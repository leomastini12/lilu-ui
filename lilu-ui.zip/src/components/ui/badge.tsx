
import React from 'react'
import clsx from 'clsx'
export function Badge({children, className, variant='default'}: any){
  const variants:any = {
    default: 'bg-slate-900 text-white',
    secondary: 'bg-slate-100 text-slate-700'
  }
  return <span className={clsx('inline-flex items-center px-2 py-0.5 text-xs rounded-md', variants[variant], className)}>{children}</span>
}
