
import React, { useState } from 'react'
export function Switch({defaultChecked}: any){
  const [on,setOn]=useState(!!defaultChecked)
  return <button onClick={()=>setOn(!on)} className={'w-11 h-6 rounded-full relative transition '+(on?'bg-purple-600':'bg-slate-300')}>
    <span className={'absolute top-0.5 left-0.5 h-5 w-5 rounded-full bg-white transition '+(on?'translate-x-5':'')}></span>
  </button>
}
