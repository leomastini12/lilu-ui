
import React from 'react'
export function Textarea(props: any){
  return <textarea {...props} className={'w-full min-h-[120px] rounded-xl border p-3 outline-none focus:ring-2 focus:ring-purple-300 '+(props.className||'')} />
}
