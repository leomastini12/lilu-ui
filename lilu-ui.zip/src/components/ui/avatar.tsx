
import React from 'react'
export function Avatar({children, className, ...props}: any){
  return <div className={'inline-flex items-center justify-center rounded-full bg-slate-200 '+(className||'')} {...props}>{children}</div>
}
export function AvatarFallback({children}: any){ return <span className='text-xs font-medium'>{children}</span> }
